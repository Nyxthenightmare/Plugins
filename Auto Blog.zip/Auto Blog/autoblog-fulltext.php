<?php
/*
Plugin Name: Auto Blog Nyx
Description: Autoblog WordPress auto fetch RSS + fulltext (Readability), RSS bisa diatur lewat menu Settings.
Version: 1.0
Author: Nyx
*/

// Autoload Composer (PSR/Log, Readability, dll)
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';
}

// Tambah interval cron custom
add_filter('cron_schedules', function($schedules){
    $schedules['minute'] = ['interval'=>60, 'display'=>'Setiap Menit'];
    $schedules['3hour'] = ['interval'=>3*60*60, 'display'=>'Setiap 3 Jam'];
    $schedules['6hour'] = ['interval'=>6*60*60, 'display'=>'Setiap 6 Jam'];
    $schedules['monthly'] = ['interval'=>30*24*60*60, 'display'=>'Setiap Bulan'];
    $schedules['yearly'] = ['interval'=>365*24*60*60, 'display'=>'Setiap Tahun'];
    return $schedules;
});

// Load modul utama
require_once __DIR__ . '/includes/fetcher.php';
require_once __DIR__ . '/includes/settings.php';
require_once __DIR__ . '/includes/fulltext.php';

// Jadwalkan cron otomatis sesuai setting
register_activation_hook(__FILE__, function() {
    $options = get_option('autoblog_settings', []);
    $interval = isset($options['interval']) ? $options['interval'] : 'hourly';
    if (!wp_next_scheduled('abft_cron_fetch')) {
        wp_schedule_event(time(), $interval, 'abft_cron_fetch');
    }
});
register_deactivation_hook(__FILE__, function() {
    wp_clear_scheduled_hook('abft_cron_fetch');
});

// Update jadwal cron jika interval berubah
add_action('update_option_autoblog_settings', function($old, $new){
    if (isset($old['interval']) && isset($new['interval']) && $old['interval'] !== $new['interval']) {
        wp_clear_scheduled_hook('abft_cron_fetch');
        wp_schedule_event(time(), $new['interval'], 'abft_cron_fetch');
    }
}, 10, 2);

// Hook cron ke fungsi fetch utama
add_action('abft_cron_fetch', 'abft_fetch_rss');