<?php
use andreskrey\Readability\Readability;
use andreskrey\Readability\Configuration;

function abft_fetch_fulltext($url) {
    // Tambahkan User-Agent agar tidak dianggap bot oleh website
    $response = wp_remote_get($url, [
        'headers' => [
            'User-Agent' => 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'
        ]
    ]);
    if (is_wp_error($response)) {
        error_log("ABFT: Error wp_remote_get $url: " . $response->get_error_message());
        return false;
    }
    $html = wp_remote_retrieve_body($response);

    // DEBUG: simpan html mentah yang diambil (cek di folder includes)
    file_put_contents(__DIR__.'/debug-html.html', $html);

    if (empty($html)) {
        error_log("ABFT: HTML kosong dari $url");
        return false;
    }

    $config = new Configuration();
    $config->setFixRelativeURLs(true);
    $config->setOriginalURL($url);

    $readability = new Readability($config);
    if (!$readability->parse($html)) {
        error_log("ABFT: Readability gagal parse $url");
        // DEBUG: simpan html yang gagal di-parse
        file_put_contents(__DIR__.'/debug-readability-fail.html', $html);
        return false;
    }

    $content = $readability->getContent();

    // DEBUG: simpan hasil content fulltext (cek di folder includes)
    file_put_contents(__DIR__.'/debug-content.html', $content);

    if (empty($content)) {
        error_log("ABFT: Readability tidak menemukan konten di $url");
        return false;
    }
    return $content;
}